<?php
require 'inc/head.php';
extract($_REQUEST);
if(isset($action)){
    if(!$loginCheck){
    
        switch($action){
    
            case 'Login':
                if(isset($username, $password) || isset($token)){
                    @$return = $client->_login($username, $password, trim(@$token));
                    if(isset($return['success'])){
                        $_SESSION['userLogin'] = md5($return['data']->username);
                        $_SESSION['userData'] = $return['data'];
                        $_SESSION['userData']->key = md5($return['data']->username);
                    }
                    break;
                }
            case 'Register':
                if(isset($username, $password,  $repassword) ){
                    if($password != $repassword){
                        $return = array('error' => true, 'msg' => 'Mật khẩu nhập lại không đúng.','url'=>'./', 'action' => $_POST);
                    }else{
                    $return = $client->_register($username, $password);
                    }
                    break;
                }
            default:
                $return = array('error' => true, 'msg' => 'No action found','url'=>'./', 'action' => $_POST);
                break;
        }
    }else{
        switch($action){
            case 'addVIP':
                if(isset($fbid, $name,$type,$speed,$goi,$expire,$sever)){
                    if($goi == null || $sever == null){
                        $return = [
				        'success' => true,
				        'msg' => 'Vui lòng chọn gói và sever'
			        ];
                    }else{
                $return = $client->_addVIP($userData, $fbid, $name,$type,$speed,$goi,$expire,$sever);
                    }
                break;
                }
            case 'logout':
		        if($loginCheck){
			        $return = $client->_logout($_SESSION['userData']);
		        }else{
			        $return = [
				        'success' => true,
				        'msg' => 'Logout!!!'
			        ];
		        }
	            session_destroy();
		        foreach($_SESSION as $key => $value){
			        unset($_SESSION[$key]);
		        }
	            break;
            default:
                $return = array('error' => true, 'msg' => 'No action found','url'=>'./', 'action' => $_POST);
                break;
        }
    }
}
?>
<?php
if(@$return){
    print '<script>alert("'.$return["msg"].'");window.location="'.$return["url"].'";</script>';
}
?>
<div class="container" style="margin-top: 70px;">
    
    
    
        
    <!-- Chưa login -->
    <?  if(!$loginCheck){?>
            <div class="row">
                <div class="col-lg-2"></div>
            <div class="col-lg-4">
                <div class="panel panel-default">
                   
                    <div class="panel-body">
                                    <form role="form" method="post">
                                        <div class="form-group input-group">
                                            <span class="input-group-addon">Tài khoản</span>
                                            <input type="text" class="form-control" name="username" placeholder="Tài khoản">
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon">Mật khẩu</span>
                                            <input type="password" class="form-control" name="password" placeholder="Mật khẩu">
                                        </div>
                                        
                                        <div class="form-group text-center">
                                            <input type="hidden" name="action" value="Login">
                                            <button type="submit" class="btn btn-success">Đăng nhập</button>
                                        </div>
                                    </form>
                            </div>
                     </div>
                 
            </div>
             <div class="col-lg-4"><div class="panel panel-default">
                   
                    <div class="panel-body">
                                    <form role="form" method="post">
                                        <div class="form-group input-group">
                                            <span class="input-group-addon">Tài khoản</span>
                                            <input type="text" class="form-control" name="username" placeholder="Tài khoản">
                                        </div>
                                        <div class="form-group input-group">
                                            <span class="input-group-addon">Mật khẩu</span>
                                            <input type="password" class="form-control" name="password" placeholder="Mật khẩu">
                                        </div>
                                         <div class="form-group input-group">
                                            <span class="input-group-addon">Nhập lại</span>
                                            <input type="password" class="form-control" name="repassword" placeholder="Nhập lại mật khẩu">
                                        </div>
                                        <div class="form-group text-center">
                                            <input type="hidden" name="action" value="Register">
                                            <button type="submit" class="btn btn-success">Đăng ký</button>
                                        </div>
                                    </form>
                            </div>
                     </div>
                 </div>
              <div class="col-lg-2"></div>
        </div>
            <!-- /Chưa login -->
            
            
        
        
        
        
            <? }else{ ?>
        <!-- Đã login -->
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        	
	   
<html>
<head>

<script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.12.0.min.js"></script>
<script>
    $(document).ready(function(){
        $("button").click(function(){
            $("#abc").toggle(500);    $("#abc2").toggle(500);  
        })
    })
</script>
</head>
<body>
  <p>  <h2>BÁO GIÁ </h2> <button>Hiện/Ẩn</button></p>
  <div  id="abc">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

  
  <table class="table">
    <thead>
     
         
        <th class="text-center">TÊN GÓI</th>
       
        <th class="text-center">BẢNG GIÁ THEO NGÀY</th>
        <th class="text-center">BẢNG GIÁ THEO THÁNG</th>
      </tr>
    </thead>
    <tbody>
        
         <tr class="info">
        <tr>
        <td>Gói Vip 1</td>
   
        <td>600 Xu / 1 ngày</td>
       <td>20.000 Xu / 1 tháng</td>
      </tr>   
      <tr class="info">
      <tr>
        <td>Gói Vip 2</td>
      
          <td>1500 Xu / 1 ngày</td>
       <td>50.000 Xu / 1 tháng</td>
      </tr>  
      
     <tr class="danger">
        <td>Gói Vip 3</td>
    
          <td>3000 Xu / 1 ngày</td>
        <td>100.000 Xu / 1 tháng</td>
      </tr>
       <tr class="danger">
        <td>Gói Vip 4</td>
    
          <td>5000 Xu / 1 ngày</td>
         <td>150.000 Xu / 1 tháng</td>
      </tr>
      <tr class="info">
        <td>Gói Vip 5</td>
   
          <td>6000 Xu / 1 ngày</td>
        <td>200.000 Xu / 1 tháng</td>
      </tr>
      <tr class="info">
        <td>Gói Vip 6</td>

          <td>10.000 Xu / 1 ngày</td>
         <td>300.000 Xu / 1 tháng</td>
      </tr>
     
      </tr>
    </tbody>
  </table></div>

</body>
</html>



</div>
</body>
</html>






        
      

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">


<div class="container">
  <center><h2>THÔNG BÁO </h2></center>
<button>Hiện/Ẩn</button></p>  <div  id="abc2">

  <div class="alert alert-success alert-dismissible fade in">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
   </strong> <p>- Chỉ cài trên các server còn trống
   <p>----------------------------
    </strong> <p>- Lưu ý hiện tại facebook chặn 1 số bài không lên like như bên dưới
<p>- Bài share không lên like
<p>- Bài chứa link không lên like
<p>- Đây là thuật toán mới của fb nên tạm thời các bạn thông báo khách vậy nhé .
<p>----------------------------
<p> Hiện nay facebook đang quét mạnh các like ảo . Nên có 1 số bài bị tuột like . Đây là tình trạng chung nên các bạn không cần lo lắng . Dự kiến hết tháng 6 facebook sẽ ngừng quét
  </div>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<div class="container">
  <center><h2>DANH SÁCH SV BẢO TRÌ</h2></center>
  
  
  <div class="alert alert-danger">

    <a href="#" class="alert-link">- 0 </a>.
    </div>
        </div>
</body>
</html>


        <div class="row"><div class="col-lg-3"> <p><h4>Xin chào, <b><?=$userData->username;?></b>.</h4></p>
                <p>Balance: <b style="color:red"><?=number_format($userData->balance);?> Xu.</b></p></div>
            

                
                
                
                
                
                <div class="col-lg-9 text-center"><? $sv = $client->_getStats();
                foreach($sv as $stt=>$key){
                    echo '<div class="col-xs-6 col-sm-4 col-lg-3 text-center"><button type="button" class="btn btn-primary" style="min-width:190px"> ' . $stt . ' : <span class="badge"> ' .  (($config['maxsv'] - $key) == 0 ? 'FULL':'Còn trống '.($config['maxsv'] - $key).' UID').'</span></button></div>';
                }
                ?>
                </div>
                
            
        
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                </div></div>
                <br/>
                
                
					
                
                
                
                
                
                
                
                
                
                
                
                <div class="row"><div class="col-lg-12">
                    <div class="panel panel-default">
                         <div class="panel-body">
                    <form method="POST">
                         <input type="hidden" name="action" value="addVIP">
				<div class="modal-body">
				    
					<div class="form-group"> <label>UID</label> <input type="text" name="fbid" placeholder="4" class="form-control" required=""> </div>
					<div class="form-group"> <label>Gói</label> <select name="goi" class="form-control">
                            <option value="">Chọn gói sử dụng</option>
                            <option value="1">Gói 1 Từ 20 đến 100 like / 1 post</option>
                                                        
                            <option value="2">Gói 2 Từ 100 đến 200 like / 1 post</option>
                                                        
                            <option value="3">Gói 3 Từ 300 đến 400 like / 1 post</option>
                                                        
                            <option value="4">Gói 4 Từ 500 đến 600 like / 1 post</option>
                                                        
                            <option value="5">Gói 5 Từ 700 đến 800 like / 1 post</option>
                                                        
                            <option value="6">Gói 6 Từ 1000 đến 1200 like / 1 post</option>
                                                        
                       
 
                                                        
                                                            
                            </select> </div>
					<div class="form-group"> <label>Thời hạn / ngày</label>  <input type="text" name="expire" placeholder="1" class="form-control" required=""></div>
					<div class="form-group"> <label>Cách thức</label> <input checked="" type="checkbox" class="form-check-input" name="type[]" value="LIKE">
<img src="https://likethue.com/assets/img/like.png" class="img-circle" alt="Cinque Terre" width="27" height="27"> 
<input type="checkbox" class="form-check-input" name="type[]" value="HAHA">
<img src="https://likethue.com/assets/img/haha.svg" class="img-circle" alt="Cinque Terre" width="27" height="27"> 
<input type="checkbox" class="form-check-input" name="type[]" value="WOW">
<img src="https://likethue.com/assets/img/wow.svg" class="img-circle" alt="Cinque Terre" width="27" height="27"> 
<input type="checkbox" class="form-check-input" name="type[]" value="ANGRY">
<img src="https://likethue.com/assets/img/angry.svg" class="img-circle" alt="Cinque Terre" width="27" height="27"> 
<input type="checkbox" class="form-check-input" name="type[]" value="LOVE">
<img src="https://likethue.com/assets/img/love.svg" class="img-circle" alt="Cinque Terre" width="27" height="27"> 
<input type="checkbox" class="form-check-input" name="type[]" value="SAD">
<img src="https://likethue.com/assets/img/sad.svg" class="img-circle" alt="Cinque Terre" width="27" height="27">  </div>
					<div class="form-group"> <label>Tốc độ</label> <select name="speed" class="form-control">
                               <option value="5">5 lượt like / 2 phút</option> 
                                <option value="10">10 lượt like / 2 phút</option> 
                     >
                               
                            </select> </div>
                            	<div class="form-group"> <label>Sever</label> <select name="sever" class="form-control">
                            	    <option value="">Vui lòng chọn gói trước</option>
                               
                            </select> </div>
					<div class="form-group"> <label>Chú thích:</label> <input type="text" name="name" placeholder="Viết gì đó ví dụ ngày hết hạn" class="form-control" required=""> </div>
				</div>
				<div class="modal-footer">
					<div class="text-center"> <button type="submit" class="btn btn-primary">Thêm VIP</button></div> </div>
			</form>
                     </div>    

            </div>
 </div>    

            </div>
        
          <!-- /Đã login -->
          <?}?>
        </div>

<?php
require 'inc/foot.php';
?>