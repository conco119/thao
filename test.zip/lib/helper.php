<?php


function reload($url=THIS_LINK)
{
    echo "<script> window.location = '".$url."' </script>";
    exit();
}
