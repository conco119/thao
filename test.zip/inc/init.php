<?php
/**
***				SA Team (SAT-CODING)
***					Copyright(c) 2017 by SAT.
***
**/
header("Content-Type:text/html;charset=utf-8");
date_default_timezone_set('Asia/Saigon');
error_reporting(E_ALL);
ini_set('display_errors', 0);
include 'autoload.php';
include 'global.php';
include '../lib/helper.php';
session_start();
$config['client'] = array(
  "ip" => $_SERVER['REMOTE_ADDR'],
  "useragent" => $_SERVER['HTTP_USER_AGENT']
);
$client = new CLIENT($config);
$adminlib = new ADMIN($config);
$lstream = new LIVESTREAM($config);
define('SAT_API', true);
ignore_user_abort(true);
set_time_limit(0);

$loginCheck = isset($_SESSION['userLogin'], $_SESSION['userData']) && $_SESSION['userLogin'] == $_SESSION['userData']->key ? true : false;
if($loginCheck){
	$client->_reloadUSER($_SESSION['userData']);
	$userData = $_SESSION['userData'];
 }else{
	 unset($_SESSION['userData']);
	 unset($_SESSION['userLogin']);
 }

$s = file_get_contents('php://input');
extract($s == false ? [] : json_decode($s, true));
