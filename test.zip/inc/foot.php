  <!-- jQuery -->
    <script src="/js/jquery-3.3.1.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>
    <script>
        var gois = <?=json_encode($goirule);?>;
        $(function(){
            $('[name="goi"]').change(function(){
                var goi = $(this).val();
                data = '';
               $(gois[goi]).each(function(a) {
                   var tengoi = gois[goi][a].split("sv")[1];
                   data+= '<option value="'+gois[goi][a]+'">Sever '+tengoi+'</option>';
                });
                
                $('[name="sever"]').html(data);
            })
        })
    </script>
</body>
</html>