<a href="./index.php">
    <button class="btn btn-primary">Quản lý UID</button>
</a>
<a href="user.php">
    <button class="btn btn-primary">Quản lý user</button>
</a>
<a href="atm.php">
    <button class="btn btn-primary">Quản lý ATM</button>
</a>
<a href="hethong.php">
    <button class="btn btn-primary">Quản lý LOG</button>
</a>
<a href="/napthe/his.php">
    <button class="btn btn-primary">Quản lý Thẻ</button>
</a>
<a href="./thongbao.php">
    <button class="btn btn-primary">Quản lý thông báo</button>
</a>
<a href="./maintain.php">
    <button class="btn btn-danger">Bảo trì server</button>
</a>
